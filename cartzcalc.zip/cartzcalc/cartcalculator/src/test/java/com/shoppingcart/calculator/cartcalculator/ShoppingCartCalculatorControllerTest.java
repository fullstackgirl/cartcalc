/**
 * 
 */
/*
 * package com.shoppingcart.calculator.cartcalculator;
 * 
 * import static org.junit.Assert.*;
 * 
 * import org.junit.After; import org.junit.AfterClass; import org.junit.Before;
 * import org.junit.BeforeClass; import org.junit.Test;
 * 
 *//**
	 * @author ARajil Unit test class for {@link ShoppingCartCalculatorController}.
	 *
	 */
/*
 * public class ShoppingCartCalculatorControllerTest {
 * 
 *//**
	 * @throws java.lang.Exception
	 */
/*
 * @BeforeClass public static void setUpBeforeClass() throws Exception { }
 * 
 *//**
	 * @throws java.lang.Exception
	 */
/*
 * @AfterClass public static void tearDownAfterClass() throws Exception { }
 * 
 *//**
	 * Sets up the mock repository with dummy data.
	 */
/*
 * @Before public void setUp() throws Exception { mStudentList = new
 * ArrayList<>(); mStudentList.add(new Student("Egon Spengler", new Date(),
 * "111-22-3333")); mStudentList.add(new Student("Peter Venkman", new Date(),
 * "111-22-3334")); mStudentList.add(new Student("Raymond Stantz", new Date(),
 * "111-22-3336")); mStudentList.add(new Student("Winston Zeddemore", new
 * Date(), "111-22-3337"));
 * 
 * when(mStudentRepository.getAllStudents()).thenReturn(mStudentList);
 * when(mStudentRepository.getStudent("Peter Venkman")).thenReturn(mStudentList.
 * get(1)); }
 * 
 *//**
	 * @throws java.lang.Exception
	 *//*
		 * @After public void tearDown() throws Exception { }
		 * 
		 * @Test public void test() { fail("Not yet implemented"); }
		 * 
		 * 
		 * // Need to use @Mock, rather than @MockBean to auto create a mock and inject
		 * it in to a Bean in to StudentController
		 * 
		 * @MockBean private StudentRepository mStudentRepository;
		 * 
		 * @InjectMocks private StudentController mStudentController;
		 * 
		 * @Captor private ArgumentCaptor<Student> mStudentCaptor;
		 * 
		 * private List<Student> mStudentList;
		 * 
		 * @Test public void listStudents() throws Exception { MvcResult result =
		 * mMockMvc.perform(get("/students/list")) .andDo(print())
		 * .andExpect(jsonPath("$", hasSize(mStudentList.size())))
		 * .andExpect(jsonPath("$.[*].name", hasItems("Peter Venkman", "Egon Spengler",
		 * "Raymond Stantz", "Winston Zeddemore"))) .andExpect(status().isOk())
		 * .andReturn();
		 * 
		 * // alternate way of verifying, convert JSON to list of objects, and verify.
		 * String content = result.getResponse().getContentAsString(); List<Student>
		 * students = mapFromJsonToList(content, Student.class); for (int i = 0; i <
		 * students.size(); i++) { Student student1 = students.get(i);
		 * assertEquals(mStudentList.get(i).getName(), student1.getName()); } }
		 * 
		 * @Test public void getStudentByName_ValidName() throws Exception {
		 * mMockMvc.perform(get("/students/{name}", "Peter Venkman")) .andDo(print())
		 * .andExpect(jsonPath("$.name", is("Peter Venkman")))
		 * .andExpect(status().isOk()) .andReturn(); }
		 * 
		 * @Test public void getStudentByName_InValidName() throws Exception {
		 * mMockMvc.perform(get("/students/{name}", "Random Name")) .andDo(print())
		 * .andExpect(status().isBadRequest()) .andReturn(); }
		 * 
		 * @Test public void addStudent() throws Exception {
		 * mMockMvc.perform(post("/students/add") .param("name", "Urist McTester")
		 * .param("socialSecurityNumber", "12345") .param("birthDate", "2010-04-05"))
		 * .andDo(print()) .andExpect(status().isOk()) // note, this is testing the JSON
		 * properties with the specific names defined in Student class
		 * .andExpect(jsonPath("$.name", is("Urist McTester")))
		 * .andExpect(jsonPath("$.SSN", is("12345"))) .andExpect(jsonPath("$.DOB",
		 * is("2010-04-05")));
		 * 
		 * ArgumentCaptor<Student> studentCaptor =
		 * ArgumentCaptor.forClass(Student.class);
		 * verify(mStudentRepository).addStudent(studentCaptor.capture());
		 * 
		 * assertEquals("The student repository wasn't called to add the student",
		 * "Urist McTester", studentCaptor.getValue().getName()); }
		 * 
		 * @Test public void addStudentMissingParametersBadRequest() throws Exception {
		 * mMockMvc.perform(post("/students/add") .param("name", "Urist McTester2"))
		 * .andDo(print()) .andExpect(status().isBadRequest()); }
		 * 
		 * }
		 */