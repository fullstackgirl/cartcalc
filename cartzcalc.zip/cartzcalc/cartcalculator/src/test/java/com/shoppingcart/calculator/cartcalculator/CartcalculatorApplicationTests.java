package com.shoppingcart.calculator.cartcalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartcalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
