package service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import model.Product;
import util.ProductEnum;
import util.ProdutItemEnum;

public class ProductServiceTest {

    private ProductService productService;

    @Before
    public void setup() throws Exception {
        productService = new ProductService(Arrays.asList(
        		new Product(1, ProductEnum.ELECTRONICS, ProdutItemEnum.E_FANCY_COMPUTER, BigDecimal.valueOf(2000)),
    			new Product(2, ProductEnum.ELECTRONICS, ProdutItemEnum.E_CELLPHONE, BigDecimal.valueOf(1000)),
    			new Product(3, ProductEnum.BOOK, ProdutItemEnum.B_REFACTOR_JAVA, BigDecimal.valueOf(20)),
    			new Product(4, ProductEnum.CLOTHES, ProdutItemEnum.C_SWEATER, BigDecimal.valueOf(30))

        ));
    }

    @Test
    public void getProductCodes_shouldReturnAllCodes() throws Exception {
    	System.out.println("Starting");
        List<Integer> productIds = productService.getProductIds();
        assertEquals(2, productIds.size());
        assertEquals(3, productIds.size());
        assertEquals(4, productIds.size());
       // assertEquals("PROD_01", productIds.get(0));
      //  assertEquals("PROD_02", productIds.get(1));
    }

	/*
	 * @Test public void getProduct_shouldReturnProductForKnownCode() throws
	 * Exception { Product product = productService.getProduct("PROD_01");
	 * assertEquals("PROD_01", product.getProductCode()); assertEquals("Product 01",
	 * product.getName()); assertEquals(1.50, product.getPrice(), 0.00); }
	 * 
	 * @Test public void getProduct_shouldReturnNullForUnknownCode() throws
	 * Exception { Product product = productService.getProduct("PROD_03");
	 * assertNull(product); }
	 */
}