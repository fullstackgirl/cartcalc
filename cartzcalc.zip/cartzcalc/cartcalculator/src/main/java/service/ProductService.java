package service;

import org.springframework.stereotype.Service;

import model.Product;
import util.ProductEnum;
import util.ProdutItemEnum;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

	// These details would be ideally retrieved from the database .
	// It can be placed in PRODUCT_ITEM table to map these fields in the respective column

	private static final List<Product> PRODUCTS = Arrays.asList(

			new Product(1, ProductEnum.ELECTRONICS, ProdutItemEnum.E_FANCY_COMPUTER, BigDecimal.valueOf(2000)),
			new Product(2, ProductEnum.ELECTRONICS, ProdutItemEnum.E_CELLPHONE, BigDecimal.valueOf(1000)),
			new Product(3, ProductEnum.BOOK, ProdutItemEnum.B_REFACTOR_JAVA, BigDecimal.valueOf(20)),
			new Product(4, ProductEnum.CLOTHES, ProdutItemEnum.C_SWEATER, BigDecimal.valueOf(30))

	);

	private List<Product> products;

	public ProductService() {
		this.products = PRODUCTS;
	}

	public ProductService(final List<Product> products) {
		this.products = products;
	}

	public List<Integer> getProductIds() {
		return products.stream().map(Product::getId).collect(Collectors.toList());
	}

	public Product getProduct(Integer productId) {
		
			 Product product = null;
		      for (Product p : PRODUCTS) {
		        if (p.getId().equals(productId)) {
		          product = p;
		          break;
		        }
		      }
		     
		
		return product;
	}
}