/**
 * 
 */
package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.Customer;
import model.Product;
import util.Utils;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author ARajil
 *
 */
@Service
public class ShoppingCartCalculatorService {
	@Autowired
	private ProductService productService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private Utils util;

	/*
	 * @Autowired public void setProductService(ProductService productService) {
	 * this.productService = productService; }
	 * 
	 * @Autowired public void setUtil(Utils util) { this.util = util; }
	 */

	// TODO Auto-generated constructor stub
	@SuppressWarnings("unlikely-arg-type")
	public BigDecimal calculate() {
		boolean extraDiscount = false;
		BigDecimal price = BigDecimal.ZERO;

		for (Integer productId : productService.getProductIds()) {

			Product product = productService.getProduct(productId);

			if (product.getCategory().equals("ELECTRONICS")) {
				price = price.add(product.getUnitPrice().multiply(BigDecimal.valueOf(0.9)));
			} else {
				price = price.add(product.getUnitPrice());
			}
		}
		extraDiscount = util.checkForExtraDiscounts(customerService.getCustomer());
		if (productService.getProductIds().size()>0 && extraDiscount) {
			price = price.multiply(BigDecimal.valueOf(0.95));
		}

		return price;

	}

}
