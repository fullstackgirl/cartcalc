package service;

import org.springframework.stereotype.Service;

import model.Customer;
import model.Product;
import util.ProductEnum;
import util.ProdutItemEnum;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

	// These details would be ideally retrieved from the database .
	// It can be placed in PRODUCT_ITEM table to map these fields in the respective
	// column

	private static Customer CUSTOMER = new Customer("1", "Asiyath", "Abdulla", LocalDate.now());
	private Customer customer;

	public CustomerService() {
		this.customer = CUSTOMER;
	}


	public Customer getCustomer() {
		return this.customer;
	}


}