package model;

import java.math.BigDecimal;

import util.ProductEnum;
import util.ProdutItemEnum;

public class Product {
	
	private Integer id;
	private ProductEnum category;
	private ProdutItemEnum name;
	private BigDecimal unitPrice;
	
	
   
	public Product(Integer id, ProductEnum category, ProdutItemEnum name, BigDecimal bigDecimal) {
         this.id = id; this.category = category; this.name = name; this.unitPrice = bigDecimal;
    }



	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public ProductEnum getCategory() {
		return category;
	}



	public void setCategory(ProductEnum category) {
		this.category = category;
	}



	public ProdutItemEnum getName() {
		return name;
	}



	public void setName(ProdutItemEnum name) {
		this.name = name;
	}



	public BigDecimal getUnitPrice() {
		return unitPrice;
	}



	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}





}
