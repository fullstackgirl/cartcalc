package model;

import java.time.LocalDate;

public class Customer {
	public String id;
	public String first;
	public String last;
	LocalDate birthDate;
	public Customer(String id, String first, String last, LocalDate birthDate) {
        this.id = id; this.first = first; this.last = last; this.birthDate = birthDate;
   }


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getLast() {
		return last;
	}

	public void setLast(String last) {
		this.last = last;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

}
