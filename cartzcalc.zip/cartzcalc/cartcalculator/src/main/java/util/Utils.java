package util;

import java.time.Year;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import model.Customer;

public class Utils {
	boolean extraDiscount = false;

	public boolean checkForExtraDiscounts(Customer customer) {

		if (getYearsRange().contains(customer.getBirthDate().getYear()) && customer.getBirthDate().getMonthValue() == 6
				&& customer.getBirthDate().getDayOfMonth() == 1) {
			extraDiscount = true;
		}
		return extraDiscount;
	}

	public List<Integer> getYearsRange() {
		String fromYear = "1980";
		String toYear = "1983";

		List<Integer> years = IntStream.rangeClosed(Integer.parseInt(Objects.requireNonNull(fromYear)),
				Integer.parseInt(Objects.requireNonNull(toYear))).boxed().collect(Collectors.toList());
		return years;
	}

}
