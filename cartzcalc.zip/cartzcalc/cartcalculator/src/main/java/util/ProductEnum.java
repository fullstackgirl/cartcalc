package util;

public enum ProductEnum {
	ELECTRONICS,
	BOOK,
	CLOTHES

}
