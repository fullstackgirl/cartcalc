package util;

/**
 * Product Item Name Class
 * Prefix E for Electronics, B for Books, C for CLothes
 * @author ARajil
 *
 */
public enum ProdutItemEnum {
	E_FANCY_COMPUTER {
	      public String toString() {
	          return "Fancy Computer";
	      }
	  },
	E_CELLPHONE {
	      public String toString() {
	          return "Cellphone";
	      }
	  },
	B_REFACTOR_JAVA {
	      public String toString() {
	          return "Refactoring Java";
	      }
	  },
	C_SWEATER {
	      public String toString() {
	          return "Sweater";
	      }
	  }
}
